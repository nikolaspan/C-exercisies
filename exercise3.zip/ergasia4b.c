#include <stdio.h>

int main() {
    float myFloat = 0.0;
    int step = 1;

    while (myFloat < 10.0) {
        printf("Βήμα %d: Τιμή = %.1f\n", step, myFloat);
        myFloat += 0.1;
        step++;
    }
printf("Βήμα %d: Τιμή = %.1f\n", step, myFloat);

  double myDouble = 0.0;
    int step1 = 1;

    while (myDouble < 10.0) {
        printf("Βήμα %d: Τιμή = %.1lf\n", step1, myDouble);
        myDouble += 0.1;
        step1++;
    }

    return 0;
}