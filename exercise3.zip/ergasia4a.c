#include <stdio.h>


int main(void) {
int count = 0;
double mp3 = 0;
double gp4 = 0;
double ga= 0;
int n = 0,num;
 // Εισαγωγή του πλήθους των αριθμών
printf("Δώστε το πλήθος των αριθμών");
 scanf("%d", &n);
 while (count < n) {
         printf("\n Δώστε έναν αριθμό: ");
        scanf("%d", &num);

        count++;

        // Υπολογισμός μέσου όρου των πολλαπλασίων του 3
        if (num % 3 == 0) {
            mp3 += num;
        }

        // Υπολογισμός γινομένου των πολλαπλασίων του 4
        if (num % 4 == 0 && num !=0) {
            if (gp4 ==0)
            {
                gp4 = 1;
            }
            gp4 = gp4 * num;
        }

        // Υπολογισμός γινομένου των αρνητικών αριθμών
        if (num < 0) {
             if (ga ==0)
            {
                ga = 1;
            }
            ga *= num;}
       


    
 } 
    printf("Πλήθος αριθμών: %d\n", count);
    printf("Μέσος όρος πολλαπλασίων του 3: %lf\n", mp3 / count);
    printf("Γινόμενο πολλαπλασίων του 4: %lf\n",gp4);
    printf("Γινόμενο αρνητικών αριθμών: %lf\n", ga);

// έκδοση με do while
int count2 = 0;
double mp32 = 0;
double gp42 = 0;
double ga2= 0;
int n2 = 0,num2;
printf("Δώστε το πλήθος των αριθμών");
 scanf("%d", &n2);
do
{

 printf("\n Δώστε έναν αριθμό: ");
        scanf("%d", &num2);

        count2++;

        // Υπολογισμός μέσου όρου των πολλαπλασίων του 3
        if (num % 3 == 0) {
            mp32 += num2;
        }

        // Υπολογισμός γινομένου των πολλαπλασίων του 4
        if (num2 % 4 == 0 && num2 !=0) {
            if (gp42 ==0)
            {
                gp42 = 1;
            }
            gp42 = gp42 * num2;
        }

        // Υπολογισμός γινομένου των αρνητικών αριθμών
        if (num2< 0) {
             if (ga2 ==0)
            {
                ga2 = 1;
            }
            ga2 *= num2;}
} while (count2 < n2);

    printf("Πλήθος αριθμών: %d\n", count2);
    printf("Μέσος όρος πολλαπλασίων του 3: %lf\n", mp32 / count2);
    printf("Γινόμενο πολλαπλασίων του 4: %lf\n",gp42);
    printf("Γινόμενο αρνητικών αριθμών: %lf\n", ga2);

return 0;
}