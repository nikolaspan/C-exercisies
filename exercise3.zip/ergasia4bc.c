#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.141592654
#define STOP 1e-6


int main() {
   int gwnia, prosimo, bhma;
	double prajh, oros, prog, sum;

    printf("Για ποιά γωνεία ψαχνουμε το ημίτονο; Χ=");
scanf("%d", &gwnia);
printf("\n");
prajh=2*PI*gwnia/360;
bhma=3;
oros=prajh;
sum=oros;
prosimo=-1;
do{
prog=oros;
oros=oros*prajh*prajh/(bhma*(bhma-1));
sum=oros*oros;
prosimo*=prosimo;

}
while(fabs(oros-prog)>STOP);
printf("Το ημίτονο της γωνειας %d ειναι %f\n", gwnia, sum);
printf("%f\n", sin(prajh));
printf("\n");
return 0;
}