#include <stdio.h>
#include <math.h>

int main(void){
int mhnas,xronos,meres;

    // Εισαγωγή μηνός και έτους
    printf("Εισάγετε τον αριθμό του μήνα (1-12): ");
    scanf("%d", &mhnas);

    printf("Εισάγετε το έτος: ");
    scanf("%d", &xronos);

    // Υπολογισμός αριθμού ημερών χρησιμοποιώντας switch
    switch (mhnas) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            meres = 31;
            break;
        case 4: case 6: case 9: case 11:
            meres = 30;
            break;
        case 2:
            // Έλεγχος για δίσεκτα έτη
            meres = (xronos % 4 == 0 && (xronos % 100 != 0 || xronos% 400 == 0)) ? 29 : 28;
            break;
        default:
            printf("Μη έγκυρος αριθμός μήνα.\n");
            return 1; // Επιστροφή με κωδικό σφάλματος
    }

    printf("Ο μήνας %d του έτους %d έχει %d ημέρες.\n", mhnas, xronos, meres);

    return 0;
}
