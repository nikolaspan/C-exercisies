#include <stdio.h>
#include <math.h>


int main(void){
    float a,b,c,riza1,riza2,diakrinousa;
  printf("δώσε τους 3 όρους \n");
  scanf("%f %f %f",&a,&b,&c);
       // Υπολογισμός του διακρίνοντος
    diakrinousa = b * b - 4 * a * c;
      // Έλεγχος για την πρωτοβάθμια εξίσωση
    if (a == 0) {
        if (b == 0) {
            // Δεν υπάρχει x στην εξίσωση
            printf("Η εξίσωση δεν είναι γραμμική. Δεν υπάρχουν ρίζες.\n");
        } else {
            // Είναι πρωτοβάθμια εξίσωση
            riza1 = -c / b;
            printf("Η εξίσωση είναι πρωτοβάθμια. Μία ρίζα: %f\n", riza1);
        }
    } else {
        // Υπολογισμός του διακρίνοντος
        diakrinousa = b * b - 4 * a * c;

        // Έλεγχος του διακρίνοντος για τον τύπο των ριζών
        if (diakrinousa > 0) {
            // Δύο πραγματικές ρίζες
            riza1 = (-b + sqrt(diakrinousa)) / (2 * a);
            riza2 = (-b - sqrt(diakrinousa)) / (2 * a);

            printf("Οι ρίζες είναι πραγματικές και διάφορες.\n");
            printf("Ρίζα 1 = %f\n", riza1);
            printf("Ρίζα 2 = %f\n", riza2);
        } else if (diakrinousa == 0) {
            // Μία πραγματική ρίζα (διπλή ρίζα)
            riza1 = -b / (2 * a);

            printf("Οι ρίζες είναι πραγματικές και ίδιες.\n");
            printf("Ρίζα = %f\n", riza1);
        } else {
            // Δεν έχει πραγματικές ρίζες
            printf("Η εξίσωση δεν έχει πραγματικές ρίζες.\n");
        }
    }}