#include <stdio.h>
#include <math.h>


int main() {
    int num1, num2;
    

    printf("Δώστε δύο ακέραιους αριθμούς: ");
    scanf("%d %d", &num1, &num2);

    printf("Άθροισμα: %d\n", num1 + num2);
    printf("Διαφορά: %d\n", num1 - num2);
    printf("Γινόμενο: %d\n", num1 * num2);

    if (num2 != 0) {
        printf("Πηλίκο: %d\n", num1 / num2);
        printf("Υπόλοιπο: %d\n", num1 % num2);
    } else {
        printf("Δεν είναι δυνατή η διαίρεση με το μηδέν.\n");
    }

    printf("Πηλίκο πραγματικών αριθμών: %lf\n", (double)num1 / num2);
    
    printf("Τετράγωνο πρώτου αριθμού: %d\n", num1*num1);
    
    if (num2 >= 0) {
        printf("Τετραγωνική ρίζα δεύτερου αριθμού: %lf\n", sqrt((double)num2));
    } else {
        printf("Δεν είναι δυνατή η υπολογιστική ρίζα για αρνητικούς αριθμούς.\n");
    }
      

  

return 0;}