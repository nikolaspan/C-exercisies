#include <stdio.h>
#include <math.h>



int main(void){
double length;

    do {
        printf("Εισάγετε το μήκος της ακμής του κύβου (σε μέτρα): ");
        scanf("%lf", &length);

        if (length < 0) {
            printf("Το μήκος της ακμής πρέπει να είναι θετικό. Δοκιμάστε ξανά.\n");
        }
    } while (length < 0);

    double cube_area = length * length * length;
    double cube_volume = pow(length, 3);

    double sphere_area = 4 * M_PI * pow(length, 2);
    double sphere_volume = (4.0 / 3) * M_PI * pow(length, 3);

    printf("Εμβαδόν κύβου: %lf τετραγωνικά μέτρα\n", cube_area);
    printf("Όγκος κύβου: %lf κυβικά μέτρα\n", cube_volume);
    printf("Εμβαδόν σφαίρας: %lf τετραγωνικά μέτρα\n", sphere_area);
    printf("Όγκος σφαίρας: %lf κυβικά μέτρα\n", sphere_volume);
     double side1, side2, side3;

    do {
        printf("Εισάγετε τα μήκη των τριών πλευρών του τριγώνου: ");
        scanf("%lf %lf %lf", &side1, &side2, &side3);
        
        if (side1 < 0 || side2 < 0 || side3 < 0) {
            printf("Τα μήκη των πλευρών πρέπει να είναι θετικά. Δοκιμάστε ξανά.\n");
        }
    } while (side1 < 0 || side2 < 0 || side3 < 0);

    double s = (side1 + side2 + side3) / 2;
    double triangle_area = sqrt(s * ((s - side1) * (s - side2) * (s - side3)));

    printf("Εμβαδόν τριγώνου: %lf τετραγωνικά μέτρα\n", triangle_area);

    return 0;}