#include <stdio.h>
#include <math.h>



// Συναρτήσεις προς υλοποίηση
double factorial(int x);
double power(int x, int y);

int main(void) {
    int choice, pros, i, n, k, result2;
    double rad, result, term, deg;
    pros = -1;

    // Μενού επιλογών
    printf("Διάλεξε Επιλογή  \n");
    printf("1. Υπολογισμός ημιτόνου\n");
    printf("2. Υπολογισμός συνημιτόνου\n");
    printf("3. Υπολογισμός δύναμης\n");
    printf("4. Υπολογισμός συνδυασμών\n");
    printf("5. Υπολογισμός Μέσου Όρου\n");
    printf("Επιλογή: ");

    while (1) {
        scanf("%d", &choice);
        if (choice > 0 && choice < 6) {
            break;
        }
        printf("Λάθος επιλογή. Προσπάθησε ξανά.\n");
        printf("Επιλογή: ");
    }

    // Υπολογισμός Ημιτόνου
    if (choice == 1) {
        printf("Εισάγετε γωνία σε μοίρες: ");
        scanf("%lf", &deg);
        rad = M_PI * deg / 180;
        result = rad;

        for (i = 3; i <= 12; i += 2) {
            term = power(rad, i) * power(rad, i) / factorial(i);
            result += pros * term;
            pros *= -1;
        }

        printf("Το ημίτονο της γωνίας %lf είναι %lf\n", deg, result);
    } else if (choice == 2) { // Υπολογισμός συνημιτόνου
        result = 1;
        printf("Εισάγετε γωνία σε μοίρες: ");
        scanf("%lf", &deg);
        rad = M_PI * deg / 180;

        for (i = 2; i <= 10; i += 2) {
            term = power(rad, i) / factorial(i);
            result += pros * term;
        }

        printf("Το συνημιτόνου της γωνίας %lf είναι %lf\n", deg, result);
    } else if (choice == 3) { // υπολογισμός δύναμης
        printf("Δώσε βάση και εκθέτη: ");
        scanf("%d %d", &n, &k);
        result = power(n, k);
        printf("Για βάση = %d και δύναμη = %d, αποτέλεσμα = %lf\n", n, k, result);
    } else if (choice == 4) { // Υπολογισμός του πλήθους των συνδυασμών Ν στοιχείων ανά Κ.
        while (1) {
            printf("Εισάγετε το N: ");
            scanf("%d", &n);
            printf("Εισάγετε το K: ");
            scanf("%d", &k);

            // Έλεγχος για την εγκυρότητα των τιμών
            if (k < n) {
                break;
            }
            printf("Λάθος είσοδος. Το N πρέπει να είναι μεγαλύτερο ή ίσο του K.\n");
        }

        result = factorial(n) / (factorial(k) * factorial(n - k));
        printf("Ο αριθμός των συνδυασμών είναι: %lf\n", result);
    } else if (choice == 5) { // υπολογισμός του Μέσου Όρου
        while (1) {
            printf("Δώσε πλήθος αριθμών: ");
            scanf("%d", &n);

            if (n > 0) {
                break;
            }
            printf("Λάθος είσοδος. Το πλήθος πρέπει να είναι θετικό.\n");
        }

        result2 = 0;
        for (i = 0; i < n; i++) {
            printf("Δώσε νούμερο: ");
            scanf("%d", &k);
            result2 += k;
        }

        result = (double)result2 / n;
        printf("Ο Μέσος Όρος είναι: %lf\n", result);
    }

    return 0;
}

double power(int x, int y) {
    unsigned long long int i, sum = 1;
    for (i = 1; i <= y; i++) {
        sum = sum * x;
    }
    return sum;
}

double factorial(int x) {
    int i, sum = 1;
    if (x == 0 || x == 1) {
        return 1;
    }
    for (i = 1; i <= x; i++) {
        sum = sum * i;
    }
    return sum;
}
