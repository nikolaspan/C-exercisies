#include <endian.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  <string.h>
#define Max 30 //μέγιστος αριθμός γραμμάτων κάθε λέξης
#define ALPHABET_SIZE 26

void calculateFrequency(char **words, int **frequency,int lineNumber);
void sortFrequencyMatrix(int **frequencyMatrix);
void printCombinations(int **frequencyMatrix);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Invalid number of parameters \n");
        return 0;
    }
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Cannot read input file \n");
        return 0;
    }
    int lineNumber = 1;
    
   while (!feof(file)) {
        char c;
        while ((c = fgetc(file)) != EOF && c != '\n') {
            // Διαβάζουμε τους χαρακτήρες ανά γραμμή, αλλά δεν τους αποθηκεύουμε
        }
        lineNumber++;
    }
    rewind(file);
   char **words=(char**)malloc(lineNumber* sizeof(char*));
       if (words == NULL) {
        printf("Memory Problem\n");
        fclose(file);
        return 1;
    }
    for (int i = 0; i < lineNumber; i++) {
        words[i] = (char *)malloc(Max * sizeof(char));
        if (words[i] == NULL) {
            printf("Memory Problem\n");
            // Αποδέσμευση προηγούμενων γραμμών
            for (int j = 0; j < i; j++) {
                free(words[j]);
            }
            free(words);
            fclose(file);
            return 1;
        }
             fgets(words[i], Max, file);
    }
  // Ελέγχουμε το περιεχόμενο του αρχείου γραμμή προς γραμμή
    for (int i = 0; i < lineNumber; i++) {
        // Ελέγχουμε αν η γραμμή περιέχει μόνο κεφαλαίους χαρακτήρες
        for (int j = 0; words[i][j] != '\0'; j++) {
            if (!(words[i][j] >= 'A' && words[i][j] <= 'Z') && words[i][j] != '\n') {
                // Αν εντοπιστεί μη έγκυρος χαρακτήρας, εκτυπώνουμε το μήνυμα λάθους
                printf("Invalid Data in Line %07d\n", i + 1);
                // Αποδέσμευση μνήμης
                for (int k = 0; k < lineNumber; k++) {
                    free(words[k]);
                }
                free(words);
                fclose(file);
                return 1;
            }
        }
    }
    int **frequencyMatrix = (int **)malloc(ALPHABET_SIZE * sizeof(int *));
    for (int i = 0; i < ALPHABET_SIZE; i++) {
        frequencyMatrix[i] = (int *)malloc(2 * sizeof(int));
        frequencyMatrix[i][0] = 'A' + i;  // Αρχικοποίηση του πρώτου στοιχείου με το γράμμα
        frequencyMatrix[i][1] = 0;        // Αρχικοποίηση του δεύτερου στοιχείου με μηδέν
    }
    calculateFrequency( words, frequencyMatrix,lineNumber);
    sortFrequencyMatrix(frequencyMatrix);
    for (int i = 0; i < 26; i++) {
        printf("%c %07d\n", frequencyMatrix[i][0], frequencyMatrix[i][1]);
    }
    printCombinations(frequencyMatrix);

    // Αποδέσμευση μνήμης
    for (int i = 0; i < lineNumber; i++) {
        free(words[i]);
    }
    free(words);

    for (int i = 0; i < ALPHABET_SIZE; i++) {
        free(frequencyMatrix[i]);
    }
    free(frequencyMatrix);

    fclose(file);
    
return 0;
}

void calculateFrequency(char **words, int **frequencyMatrix,int lineNumber) {
    for (int i = 0; i < lineNumber; i++) {
        for (int j = 0; words[i][j] != '\0'; j++) {
            if (words[i][j] >= 'A' && words[i][j] <= 'Z') {
                int index = words[i][j] - 'A';
                frequencyMatrix[index][1]++;
            }
        }
    }
}
void sortFrequencyMatrix(int **frequencyMatrix) {
    // Υλοποίηση απλής ταξινόμησης (bubble sort) σε φθίνουσα τάξη
    for (int i = 0; i < 25; i++) {
        for (int j = 0; j < 25 - i; j++) {
            if (frequencyMatrix[j][1] < frequencyMatrix[j + 1][1]) {
                // Swap
                int tempLetter = frequencyMatrix[j][0];
                int tempFrequency = frequencyMatrix[j][1];
                frequencyMatrix[j][0] = frequencyMatrix[j + 1][0];
                frequencyMatrix[j][1] = frequencyMatrix[j + 1][1];
                frequencyMatrix[j + 1][0] = tempLetter;
                frequencyMatrix[j + 1][1] = tempFrequency;
            }
        }
    }
}
void printCombinations(int **frequencyMatrix) {
   
    for (int i = 0; i < 5; i++) {
        for (int j = i + 1; j < 5; j++) {
            printf("%c%c\n", frequencyMatrix[i][0], frequencyMatrix[j][0]);
        }
    }
}